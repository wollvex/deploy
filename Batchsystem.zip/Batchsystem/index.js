var tl = gsap.timeline()

tl.from("#nav a",{
    y:-100,
    opacity:0,
    delay:0.5,
    stagger:0.25
})
tl.from("#nav h1",{
    y:-100,
    opacity:0,
    delay:0.5,
    stagger:0.25
})
.from("#first p",{
    x:-500,
    opacity:0,
    stagger:0.24,
    duration:0.7
})
.from("#nav button",{
    y:-100,
    opacity:0,
    delay:0.5,
    stagger:0.25
})
.from(".op svg",{
    x:800,
    opacity:0,
    stagger:0.5,
    rotate:135
})
// .to("#main",{
//     backgroundColor: "white",
//     duration:0.5,

// })
// .to("h1",{
//     color:"#000",
//     duration:0.1,
// })
.to("#op",{
    duration:2,
    opacity:1,
    scale:1,
})
.from("h2",{
    x:-500,
    opacity:0,
    stagger:0.24,
    duration:0.7
})
.from("#first button",{
    y:-1000,
    opacity:0,
    stagger:0.2,
})
.from("#first svg",{
    y:900,
    opacity:0,
    stagger:0,
})